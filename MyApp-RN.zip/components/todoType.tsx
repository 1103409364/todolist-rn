// 常量
export const TODOTYPE: Type = {
  ALL: '0',
  UNDONE: '1',
  DONE: '2'
};
